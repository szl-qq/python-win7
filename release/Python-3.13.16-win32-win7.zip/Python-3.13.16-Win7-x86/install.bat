@echo off
chcp 936 >nul 2>nul
title Python 3.13.16 - ��װ
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo �����������ԱȨ��...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
if errorlevel 1 pause
