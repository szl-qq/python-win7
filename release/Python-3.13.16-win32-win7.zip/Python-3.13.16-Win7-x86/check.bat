@echo off
chcp 936 >nul 2>nul
title Python 3.13.16 - �Լ�
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0check.ps1" %*
if errorlevel 1 pause
